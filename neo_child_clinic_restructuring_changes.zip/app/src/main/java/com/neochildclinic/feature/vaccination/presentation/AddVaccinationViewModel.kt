package com.neochildclinic.feature.vaccination.presentation

import com.neochildclinic.feature.doctor.presentation.SlotsUiState
import com.neochildclinic.feature.doctor.presentation.loadUiState
import com.neochildclinic.feature.doctor.domain.GetAvailableSlotsUseCase
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.neochildclinic.core.common.Constants
import com.neochildclinic.domain.model.*
import com.neochildclinic.feature.inventory.domain.repository.InventoryRepository
import com.neochildclinic.feature.patient.domain.repository.PatientRepository
import com.neochildclinic.feature.reminder.domain.repository.ReminderRepository
import com.neochildclinic.feature.vaccination.domain.repository.VaccinationRepository
import com.neochildclinic.feature.vaccination.domain.ClinicalVaccinationService
import com.neochildclinic.feature.vaccination.domain.VaccinationEditEngine
import com.neochildclinic.core.security.CurrentUserProvider
import com.neochildclinic.core.security.SessionManager
import com.neochildclinic.core.common.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.*
import javax.inject.Inject

data class VaccineSelectionState(
    val id: String = UUID.randomUUID().toString(),
    val selectedVaccine: InventoryItem? = null,
    val selectedBatch: VaccineBatch? = null,
    val quantity: Int = 1
)

data class NextVaccinationItem(
    val id: String = UUID.randomUUID().toString(),
    val reminderId: String? = null,
    val type: String = "",
    val vaccine: InventoryItem? = null,
    val typeError: Boolean = false
)

data class NextVaccinationGroup(
    val id: String = UUID.randomUUID().toString(),
    val dueDate: String = "",
    val items: List<NextVaccinationItem> = listOf(NextVaccinationItem())
)

data class AddVaccinationUiState(
    val patient: Patient? = null,
    val isLoading: Boolean = false,
    val isVaccinationLoading: Boolean = false,
    val inventory: List<InventoryItem> = emptyList(),
    val availableDueTypes: List<String> = emptyList(),
    val allDoctors: List<Profile> = emptyList(),
    val selectedDoctor: Profile? = null,
    val doctorError: Boolean = false,
    val slotsState: SlotsUiState = SlotsUiState.Idle,
    val selectedSlot: AvailableSlot? = null,
    val slotError: Boolean = false,
    val givenDate: String = DateUtils.todayDateString(),
    val vaccinesGiven: List<VaccineSelectionState> = listOf(VaccineSelectionState()),
    val nextVaccinationGroups: List<NextVaccinationGroup> = emptyList(),
    val cashAmount: String = "0",
    val onlineAmount: String = "0",
    val totalAmount: Double = 0.0,
    val withFees: Boolean = false,
    val doctorsAcc: Boolean = false,
    val existingVaccinationId: String? = null,
    val saveSuccess: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class AddVaccinationViewModel @Inject constructor(
    private val patientRepository: PatientRepository,
    private val inventoryRepository: InventoryRepository,
    private val vaccinationRepository: VaccinationRepository,
    private val reminderRepository: ReminderRepository,
    private val profileRepository: com.neochildclinic.feature.profile.domain.repository.ProfileRepository,
    private val clinicalService: ClinicalVaccinationService,
    private val vaccinationEditEngine: VaccinationEditEngine,
    private val sessionManager: SessionManager,
    private val getAvailableSlotsUseCase: GetAvailableSlotsUseCase,
    private val currentUserProvider: CurrentUserProvider
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddVaccinationUiState())
    val uiState: StateFlow<AddVaccinationUiState> = _uiState.asStateFlow()

    // Snapshot of the persisted vaccination items used by Edit mode.
    // This prevents validation/save from depending solely on transient Compose selection state.
    private var originalVaccinationItems: List<VaccinationItem> = emptyList()
    private val cancelledNextReminderIds = mutableSetOf<String>()

    // The doctorId recorded on the vaccination being edited (if any). Kept separate from
    // selectedDoctor so the doctor list can include this doctor even if they're now inactive.
    private val editingDoctorId = MutableStateFlow<String?>(null)

    // The availabilitySlotId recorded on the vaccination being edited (if any) - used to
    // preselect the matching slot once availability has loaded for its doctor/date.
    private var editingAvailabilitySlotId: String? = null
    private var slotLoadToken = 0

    init {
        fetchInventory()
        fetchDoctors()
    }

    fun loadPatient(patientId: String) {
        if (patientId.isBlank()) return
        viewModelScope.launch {
            val patient = patientRepository.getPatientById(patientId)
            _uiState.update { it.copy(patient = patient) }
        }
    }

    fun loadVaccination(vaccinationId: String?) {
        if (vaccinationId.isNullOrBlank()) return
        cancelledNextReminderIds.clear()
        viewModelScope.launch {
            _uiState.update { it.copy(isVaccinationLoading = true) }
            val vaccination = vaccinationRepository.getVaccinationById(vaccinationId) ?: run {
                _uiState.update { it.copy(isVaccinationLoading = false) }
                return@launch
            }
            loadPatient(vaccination.patientId)

            // Wait until the inventory contains the vaccines AND their referenced batches.
            // getInventoryItems() combines vaccine and batch flows, so its first non-empty
            // emission can contain vaccines before the batch query has emitted. Waiting only
            // for inventory.isNotEmpty() caused Edit Vaccination to restore rows with a
            // missing batch and later fail with "Please select vaccine and batch for all rows."
            // Bounded: if a vaccine or batch this vaccination references was later deleted from
            // the catalog, this condition can never become true - an unbounded wait here used to
            // leave originalVaccinationItems at its empty default, and a save (even one that only
            // touched an unrelated field like payment) would then silently persist an empty item
            // list, wiping the vaccine names off this record. Fall through after the timeout so
            // the screen still loads (existing item data is preserved as-is; see the guard in
            // saveVaccination()).
            withTimeoutOrNull(5000) {
                uiState.filter { state ->
                    vaccination.items.all { item ->
                        val vaccine = state.inventory.firstOrNull { it.id == item.vaccineId }
                        vaccine != null && vaccine.batches.any { it.batchId == item.batchId }
                    }
                }.first()
            }

            if (vaccination.doctorId.isNotBlank()) {
                editingDoctorId.value = vaccination.doctorId
                // Wait for the doctor list to include this doctor (covers the inactive-doctor
                // case above). Falls back to "list is non-empty" so we don't hang forever if the
                // doctor record was deleted entirely rather than just deactivated.
                withTimeoutOrNull(5000) {
                    uiState.filter { state ->
                        state.allDoctors.any { it.employeeId == vaccination.doctorId || it.id == vaccination.doctorId }
                    }.first()
                }
            } else if (_uiState.value.allDoctors.isEmpty()) {
                // Bounded like its two siblings above. On a fresh install profiles holds only
                // the signed-in user and RefreshDataUseCase does not pull profiles, so this
                // filter can never match - the screen spun forever on a guaranteed path.
                withTimeoutOrNull(5000) {
                    uiState.filter { it.allDoctors.isNotEmpty() }.first()
                }
            }

            val inventory = _uiState.value.inventory
            originalVaccinationItems = vaccination.items

            val items = buildVaccineSelectionRows(vaccination.items, inventory) { inventoryRepository.getBatchById(it) }

            // Load existing Next Vaccination entries directly from reminders.
            val reminders = reminderRepository.getRemindersByVisitId(vaccinationId)
            val groups = buildNextVaccinationGroups(reminders, inventory)

            val existingDoctor = _uiState.value.allDoctors.firstOrNull {
                it.employeeId == vaccination.doctorId || it.id == vaccination.doctorId
            }
            editingAvailabilitySlotId = vaccination.availabilitySlotId

            _uiState.update { it.copy(
                existingVaccinationId = vaccinationId,
                givenDate = vaccination.dateGiven,
                selectedDoctor = existingDoctor ?: it.selectedDoctor,
                vaccinesGiven = if (items.isNotEmpty()) items else listOf(VaccineSelectionState()),
                nextVaccinationGroups = groups,
                cashAmount = vaccination.cashAmount.toInt().toString(),
                onlineAmount = vaccination.onlineAmount.toInt().toString(),
                totalAmount = vaccination.totalPaid,
                withFees = vaccination.withFees,
                doctorsAcc = vaccination.doctorsAcc,
                isVaccinationLoading = false
            ) }
            loadAvailableSlots()
        }
    }

    fun setInitialVaccine(vaccineName: String?) {
        if (vaccineName.isNullOrBlank()) return
        viewModelScope.launch {
            // Wait for inventory
            uiState.filter { it.inventory.isNotEmpty() }.first()
            
            val inventory = _uiState.value.inventory
            val vaccine = inventory.find { it.brandName.equals(vaccineName, ignoreCase = true) }
            
            if (vaccine != null) {
                val rowId = _uiState.value.vaccinesGiven.firstOrNull()?.id ?: UUID.randomUUID().toString()
                if (_uiState.value.vaccinesGiven.isEmpty()) {
                    _uiState.update { it.copy(vaccinesGiven = listOf(VaccineSelectionState(id = rowId))) }
                }
                selectVaccine(rowId, vaccine)
            }
        }
    }

    private fun fetchInventory() {
        inventoryRepository.getInventoryItems().onEach { items ->
            val types = items.map { it.type }.filter { it.isNotBlank() }.distinct().sorted()
            _uiState.update { it.copy(
                inventory = items,
                availableDueTypes = if (types.isEmpty()) Constants.DUE_VACCINATION_TYPES else types
            ) }
        }.launchIn(viewModelScope)
    }

    private fun fetchDoctors() {
        // Recomputes whenever profiles change OR the vaccination being edited (and its
        // doctorId) becomes known, so an inactive doctor who performed a past vaccination
        // is still selectable/visible when editing that record.
        combine(profileRepository.allProfiles, editingDoctorId) { profiles, editId -> profiles to editId }
            .onEach { (profiles, editId) ->
                val doctors = profiles.filter {
                    it.role == UserRole.doctor &&
                        (it.isActive || (!editId.isNullOrBlank() && (it.employeeId == editId || it.id == editId)))
                }.sortedBy { it.displayName }

                val currentUserId = sessionManager.getCurrentUserId()
                val currentUserProfile = profiles.find { it.id == currentUserId }
                val defaultDoctor =
                    if (currentUserProvider.getCurrentUserRole() == UserRole.doctor) currentUserProfile
                    else null

                _uiState.update { state ->
                    val editDoctor = editId?.let { id -> doctors.firstOrNull { it.employeeId == id || it.id == id } }
                    state.copy(
                        allDoctors = doctors,
                        selectedDoctor = editDoctor ?: if (state.selectedDoctor == null) defaultDoctor else state.selectedDoctor
                    )
                }
                loadAvailableSlots()
            }.launchIn(viewModelScope)
    }

    fun selectDoctor(doctor: Profile) {
        // Changing the doctor invalidates whatever slot was selected for the previous
        // doctor (req. 2: "never allow a slot belonging to the previous doctor to remain
        // selected"). Follow up with loadAvailableSlots().
        _uiState.update { it.copy(selectedDoctor = doctor, doctorError = false, selectedSlot = null, slotError = false) }
        loadAvailableSlots()
    }

    /** Recomputes available slots for the currently selected doctor + givenDate (req. 2/22). */
    fun loadAvailableSlots() {
        val state = _uiState.value
        val doctor = state.selectedDoctor
        if (doctor == null || state.givenDate.isBlank()) {
            _uiState.update { it.copy(slotsState = SlotsUiState.Idle, selectedSlot = null) }
            return
        }
        val token = ++slotLoadToken
        _uiState.update { it.copy(slotsState = SlotsUiState.Loading, selectedSlot = null) }
        viewModelScope.launch {
            // Keyed by profiles.id (auth uid) - see AddConsultationViewModel for why this
            // must not be employeeId.
            val result = getAvailableSlotsUseCase.loadUiState(doctor.id, state.givenDate)
            if (token != slotLoadToken) return@launch
            _uiState.update { current ->
                val preselect = editingAvailabilitySlotId
                    ?.takeIf { it.isNotBlank() }
                    ?.let { slotId -> (result as? SlotsUiState.Loaded)?.slots?.firstOrNull { it.weeklySlotId == slotId } }
                current.copy(slotsState = result, selectedSlot = preselect ?: current.selectedSlot)
            }
        }
    }

    fun selectSlot(slot: AvailableSlot) {
        _uiState.update { it.copy(selectedSlot = slot, slotError = false) }
    }

    fun updateGivenDate(date: String) {
        _uiState.update { state ->
            // Re-validate every row's current batch selection against the new given date -
            // a batch that's still in stock but expires before the new date is no longer a
            // valid selection and must be swapped for the next valid batch (or cleared).
            state.copy(givenDate = date, vaccinesGiven = revalidateRowsForDate(state.vaccinesGiven, date))
        }
        // Date change recalculates availability too (req. 22), same as a doctor change.
        loadAvailableSlots()
    }

    fun addVaccineRow() {
        _uiState.update { it.copy(vaccinesGiven = it.vaccinesGiven + VaccineSelectionState()) }
    }

    fun removeVaccineRow(id: String) {
        if (_uiState.value.vaccinesGiven.size > 1) {
            _uiState.update { it.copy(vaccinesGiven = it.vaccinesGiven.filter { row -> row.id != id }) }
        }
    }

    fun selectVaccine(rowId: String, vaccine: InventoryItem) {
        val givenDate = _uiState.value.givenDate
        val bestBatch = bestAvailableBatch(vaccine, givenDate)

        _uiState.update { state ->
            val updated = state.vaccinesGiven.map { row ->
                if (row.id == rowId) row.copy(selectedVaccine = vaccine, selectedBatch = bestBatch)
                else row
            }
            state.copy(vaccinesGiven = updated)
        }
    }

    fun selectBatch(rowId: String, batch: VaccineBatch) {
        _uiState.update { state ->
            val updated = state.vaccinesGiven.map { row ->
                if (row.id == rowId) row.copy(selectedBatch = batch)
                else row
            }
            state.copy(vaccinesGiven = updated)
        }
    }

    fun updateQuantity(rowId: String, quantity: String) {
        val parsed = quantity.toIntOrNull()?.coerceAtLeast(1) ?: return
        _uiState.update { state ->
            state.copy(vaccinesGiven = state.vaccinesGiven.map { row ->
                if (row.id == rowId) row.copy(quantity = parsed) else row
            })
        }
    }

    fun updateCash(amount: String) {
        val cash = amount.toDoubleOrNull() ?: 0.0
        val online = _uiState.value.onlineAmount.toDoubleOrNull() ?: 0.0
        _uiState.update { it.copy(cashAmount = amount, totalAmount = cash + online) }
    }

    fun updateOnline(amount: String) {
        val online = amount.toDoubleOrNull() ?: 0.0
        val cash = _uiState.value.cashAmount.toDoubleOrNull() ?: 0.0
        _uiState.update { it.copy(onlineAmount = amount, totalAmount = cash + online) }
    }

    fun updateWithFees(enabled: Boolean) {
        _uiState.update { it.copy(withFees = enabled) }
    }

    fun updateDoctorsAccount(enabled: Boolean) {
        _uiState.update { it.copy(doctorsAcc = enabled) }
    }

    fun addNextVaccinationGroup() {
        _uiState.update { it.copy(nextVaccinationGroups = it.nextVaccinationGroups + NextVaccinationGroup()) }
    }

    fun removeNextVaccinationGroup(groupId: String) {
        _uiState.update { state ->
            state.copy(nextVaccinationGroups = state.nextVaccinationGroups.filter { it.id != groupId })
        }
    }

    fun updateNextVaccinationGroupDate(groupId: String, dueDate: String) {
        _uiState.update { state ->
            state.copy(nextVaccinationGroups = state.nextVaccinationGroups.map { group ->
                if (group.id == groupId) group.copy(dueDate = dueDate) else group
            })
        }
    }

    fun addNextVaccinationItem(groupId: String) {
        _uiState.update { state ->
            state.copy(nextVaccinationGroups = state.nextVaccinationGroups.map { group ->
                if (group.id == groupId) group.copy(items = group.items + NextVaccinationItem()) else group
            })
        }
    }

    fun removeNextVaccinationItem(groupId: String, itemId: String) {
        _uiState.update { state ->
            state.copy(nextVaccinationGroups = state.nextVaccinationGroups.map { group ->
                if (group.id == groupId) {
                    val updatedItems = group.items.filter { it.id != itemId }
                    group.copy(items = updatedItems.ifEmpty { listOf(NextVaccinationItem()) })
                } else group
            })
        }
    }

    fun updateNextVaccinationItem(groupId: String, itemId: String, type: String? = null, vaccine: InventoryItem? = null) {
        _uiState.update { state ->
            state.copy(nextVaccinationGroups = state.nextVaccinationGroups.map { group ->
                if (group.id == groupId) {
                    group.copy(items = group.items.map { item ->
                        if (item.id == itemId) {
                            item.copy(
                                type = type ?: item.type,
                                vaccine = if (type != null) null else (vaccine ?: item.vaccine),
                                typeError = if (type != null) false else item.typeError
                            )
                        } else item
                    })
                } else group
            })
        }
    }

    fun cancelNextVaccinationGroup(groupId: String) {
        val group = _uiState.value.nextVaccinationGroups.find { it.id == groupId } ?: return
        viewModelScope.launch {
            try {
                val user = sessionManager.getCurrentUserEmail()
                group.items.forEach { item ->
                    item.reminderId?.let { rId ->
                        val reminder = reminderRepository.getReminderById(rId) ?: return@let
                        reminderRepository.dismissReminder(reminder, "Cancelled from Next Vaccination Group", user)
                        cancelledNextReminderIds += rId
                    }
                }
                _uiState.update { state ->
                    state.copy(nextVaccinationGroups = state.nextVaccinationGroups.filter { it.id != groupId })
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = e.message ?: "Unable to cancel group") }
            }
        }
    }

    fun cancelNextVaccinationItem(groupId: String, itemId: String) {
        val group = _uiState.value.nextVaccinationGroups.find { it.id == groupId } ?: return
        val item = group.items.find { it.id == itemId } ?: return
        val reminderId = item.reminderId

        if (reminderId.isNullOrBlank()) {
            removeNextVaccinationItem(groupId, itemId)
            return
        }

        viewModelScope.launch {
            try {
                val reminder = reminderRepository.getReminderById(reminderId) ?: return@launch
                val user = sessionManager.getCurrentUserEmail()

                if (reminder.nxtVaccineId != null && reminder.nxtVaccineId.size > 1 && item.vaccine != null) {
                    // It's a multi-vaccine reminder, but our UI redesign treats them as separate items.
                    // The underlying repository logic for cancelNextVaccinationVaccine expects the ID.
                    reminderRepository.cancelNextVaccinationVaccine(
                        reminder = reminder,
                        vaccineId = item.vaccine.id,
                        reason = "Cancelled from Next Vaccination",
                        performedBy = user
                    )
                } else {
                    // Single vaccine or type-only reminder
                    reminderRepository.dismissReminder(reminder, "Cancelled from Next Vaccination", user)
                    cancelledNextReminderIds += reminderId
                }

                _uiState.update { state ->
                    state.copy(nextVaccinationGroups = state.nextVaccinationGroups.map { g ->
                        if (g.id == groupId) {
                            val updated = g.items.filter { it.id != itemId }
                            g.copy(items = updated.ifEmpty { listOf(NextVaccinationItem()) })
                        } else g
                    })
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = e.message ?: "Unable to cancel item") }
            }
        }
    }

    fun saveVaccination(
        editGivenDate: Boolean = true,
        editDoctor: Boolean = true,
        editVaccineBatch: Boolean = true,
        editQuantity: Boolean = true,
        editNextVaccination: Boolean = true
    ) {
        val state = _uiState.value
        val patient = state.patient ?: return

        val isEdit = !state.existingVaccinationId.isNullOrBlank()
        val editSchedule = editGivenDate || editDoctor

        // Doctor + slot are only required when the schedule (date/doctor) is actually
        // being edited. A payment-only edit must not fail because the recorded slot no
        // longer resolves in the availability list, and when the Doctor checkbox stays
        // off but the date is being edited the slot dropdown is shown while the doctor
        // list is hidden - requiring a slot here is safe because the dropdown renders
        // whenever editGivenDate is set (see AddVaccinationScreen).
        if (!isEdit || editSchedule) {
            if (state.selectedDoctor == null) {
                _uiState.update { it.copy(doctorError = true, errorMessage = "Please select a doctor.") }
                return
            }
        }

        // Defense in depth: if this is an edit that isn't touching Vaccine & Batch, the save
        // path below relies on originalVaccinationItems (the persisted item snapshot from
        // loadVaccination()). If that snapshot never populated - e.g. loadVaccination() was
        // still waiting on inventory data, or timed out because a referenced vaccine/batch was
        // deleted from the catalog - saving here would silently persist an empty item list and
        // wipe the vaccine names off this record. Refuse rather than corrupt existing data.
        if (isEdit && !editVaccineBatch && originalVaccinationItems.isEmpty()) {
            _uiState.update { it.copy(
                errorMessage = "Vaccine details haven't finished loading yet. Please wait a moment and try again, or check \"Vaccine & Batch\" to re-enter them."
            ) }
            return
        }

        if (state.vaccinesGiven.any { it.selectedVaccine == null || it.selectedBatch == null }) {
            if (!isEdit || editVaccineBatch) {
                _uiState.update { it.copy(errorMessage = "Please select vaccine and batch for all rows.") }
                return
            }
        }

        val nextGroups = state.nextVaccinationGroups

        if (nextVaccinationSectionActive(isEdit = isEdit, editNextVaccination = editNextVaccination)) {
            validateNextGroups(nextGroups)?.let { validation ->
                _uiState.update { s ->
                    s.copy(
                        errorMessage = validation.errorMessage,
                        nextVaccinationGroups = validation.groupsWithErrors
                    )
                }
                return
            }
        }

        _uiState.update { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch {
            try {
                val user = sessionManager.getCurrentUserEmail()
                val vaccinationId = state.existingVaccinationId ?: UUID.randomUUID().toString()

                val existingVaccination = if (isEdit) {
                    vaccinationRepository.getVaccinationById(vaccinationId)
                } else null

                // When the schedule section is untouched, carry the originally recorded
                // doctor/slot through unchanged instead of diffing against a blanked
                // selection - the original slot may not even be in the availability list
                // anymore, and a payment-only edit must not rewrite the schedule.
                val preserveOriginalSchedule = isEdit && !editSchedule
                val doctorId = if (preserveOriginalSchedule) {
                    (existingVaccination?.doctorId ?: "").ifBlank {
                        state.selectedDoctor?.employeeId ?: state.selectedDoctor?.id ?: ""
                    }
                } else {
                    val doctor = state.selectedDoctor!!
                    doctor.employeeId ?: doctor.id
                }
                val performedBy = if (preserveOriginalSchedule) {
                    existingVaccination?.performedBy ?: state.selectedDoctor?.displayName ?: ""
                } else {
                    state.selectedDoctor!!.displayName
                }
                val availabilitySlotId = if (preserveOriginalSchedule) {
                    existingVaccination?.availabilitySlotId
                } else {
                    state.selectedSlot?.weeklySlotId
                }

                // Every item keeps its stable row identity: rows loaded from the DB carry
                // their vaccination_items id (selection.id), rows added in the UI carry a
                // fresh UUID. EditReconciler decides per row whether to KEEP it, replace
                // it (DELETE old + CREATE new id), delete it, or create it. Ids are never
                // regenerated here - doing so destroys the identity before reconciliation.
                val items = if (isEdit && !editVaccineBatch) {
                    originalVaccinationItems.map { original ->
                        val row = state.vaccinesGiven.find { it.id == original.id }
                        original.copy(
                            vaccinationId = vaccinationId,
                            quantity = if (editQuantity) row?.quantity ?: original.quantity else original.quantity
                        )
                    }
                } else {
                    state.vaccinesGiven.map { selection ->
                        VaccinationItem(
                            id = selection.id,
                            vaccinationId = vaccinationId,
                            vaccineId = selection.selectedVaccine!!.id,
                            vaccineName = selection.selectedVaccine.brandName,
                            batchId = selection.selectedBatch!!.batchId,
                            batchNumber = selection.selectedBatch.batchNumber,
                            expiryDate = selection.selectedBatch.expiryDate,
                            quantity = selection.quantity,
                            mrp = selection.selectedBatch.sellingPrice,
                            netRate = selection.selectedBatch.purchaseCost
                        )
                    }
                }

                val vaccination = Vaccination(
                    id = vaccinationId,
                    patientId = patient.id,
                    patientName = patient.name,
                    patientClinicId = patient.patientClinicId,
                    dateGiven = state.givenDate,
                    cashAmount = state.cashAmount.toDoubleOrNull() ?: 0.0,
                    onlineAmount = state.onlineAmount.toDoubleOrNull() ?: 0.0,
                    totalPaid = state.totalAmount,
                    withFees = state.withFees,
                    doctorsAcc = state.doctorsAcc,
                    doctorId = doctorId,
                    performedBy = performedBy,
                    availabilitySlotId = availabilitySlotId,
                    items = items,
                    nextVaccinations = emptyList(),
                    status = com.neochildclinic.domain.model.ReminderStatus.COMPLETED
                )

                // Transform grouped UI state back to flat ReminderSpec list
                val reminderSpecs = nextGroups.flatMap { group ->
                    // Group items by Type under the same Date to keep compatibility with existing ReminderRepository logic
                    // which expects a list of vaccines for a single type.
                    // Actually, the requirements say "Each Type + Vaccine combination creates a separate reminder item".
                    // But the existing repository saveNextVaccination takes List<String> vaccineNames.
                    // If we want "separate reminder item" for each combo, we should send them one by one.
                    // HOWEVER, if they have the same Type and same Date, they are usually grouped in this app.
                    // Let's stick to the "Each combo is a row" in UI, but keep the "Type-based grouping" for saving
                    // if they share the same Type and Date, OR just send them as individual specs.
                    // The requirement says: 15 Oct 2026 Booster -> DPT, Primary -> MMR, Optional -> NULL
                    // creates 3 separate reminders.
                    group.items.map { item ->
                        VaccinationEditEngine.ReminderSpec(
                            reminderId = item.reminderId,
                            type = item.type,
                            vaccineNames = listOfNotNull(item.vaccine?.brandName),
                            vaccineIds = listOfNotNull(item.vaccine?.id),
                            dueDate = group.dueDate,
                            notes = "Scheduled during visit on ${state.givenDate}"
                        )
                    }
                }

                if (isEdit && existingVaccination != null) {
                    // All edit side effects are diff-driven. Unchanged inventory, finance,
                    // vaccination-item identity, and reminders produce no transactions.
                    vaccinationEditEngine.execute(
                        original = existingVaccination,
                        updated = vaccination,
                        user = user,
                        reminderSpecs = reminderSpecs,
                        excludedReminderIds = cancelledNextReminderIds
                    )
                } else {
                    // New vaccination keeps the existing creation workflow.
                    // Reminders go in with the visit, inside the same transaction. Writing
                    // them here afterwards meant a reminder failure rolled back nothing:
                    // the visit and its stock deduction were already committed, the UI said
                    // "failed", and a retry produced a second visit whose items REPLACED the
                    // first's - two visits, one item set, two stock deductions (NCC-004).
                    clinicalService.recordVaccination(
                        vaccination = vaccination,
                        user = user,
                        isNew = true,
                        reminderSpecs = reminderSpecs
                    )
                }

                _uiState.update { it.copy(isLoading = false, saveSuccess = true) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage = e.message) }
            }
        }
    }
}
