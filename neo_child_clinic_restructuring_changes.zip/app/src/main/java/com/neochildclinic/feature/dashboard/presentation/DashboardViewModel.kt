package com.neochildclinic.feature.dashboard.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.neochildclinic.domain.model.SyncState
import com.neochildclinic.domain.model.UserRole
import com.neochildclinic.domain.model.Profile
import com.neochildclinic.feature.borrowed.domain.repository.BorrowRepository
import com.neochildclinic.feature.inventory.domain.repository.InventoryRepository
import com.neochildclinic.feature.patient.domain.repository.PatientRepository
import com.neochildclinic.feature.patient.domain.repository.PatientTodoRepository
import com.neochildclinic.feature.profile.domain.repository.ProfileRepository
import com.neochildclinic.feature.reminder.domain.repository.ReminderRepository
import com.neochildclinic.feature.waste.domain.repository.WasteRepository
import com.neochildclinic.feature.doctor.domain.repository.DoctorAvailabilityRepository
import com.neochildclinic.feature.sync.domain.repository.SyncRepository
import com.neochildclinic.feature.doctor.domain.GetAvailableSlotsUseCase
import com.neochildclinic.feature.finance.domain.repository.FinanceRepository
import com.neochildclinic.feature.statistics.domain.FinanceCalculator
import com.neochildclinic.feature.statistics.domain.StatisticsDateUtils
import com.neochildclinic.core.common.PatientUtils
import java.util.Calendar
import com.neochildclinic.domain.model.DoctorAvailabilityResult
import com.neochildclinic.domain.model.TimeRange
import com.neochildclinic.feature.doctor.presentation.SlotsUiState
import com.neochildclinic.feature.doctor.presentation.loadUiState
import com.neochildclinic.core.sync.RealtimeChangeSubscriptions
import com.neochildclinic.domain.model.ConsultationTodo
import com.neochildclinic.domain.model.VaccinationTodo
import com.neochildclinic.domain.model.Patient
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.neochildclinic.core.network.NetworkMonitor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val patientCount: Int = 0,
    val lowStockCount: Int = 0,
    val outOfStockCount: Int = 0,
    val borrowedCount: Int = 0,
    val dueTodayCount: Int = 0,
    val wasteCount: Int = 0,
    val syncState: SyncState = SyncState.IDLE,
    val isOnline: Boolean = false,
    val pendingSyncCount: Int = 0,
    val errorMessage: String? = null,
    val todayConsultations: List<ConsultationTodo> = emptyList(),
    val todayVaccinations: List<VaccinationTodo> = emptyList(),
    val visitedConsultations: List<ConsultationTodo> = emptyList(),
    val visitedVaccinations: List<VaccinationTodo> = emptyList(),
    val datesWithData: Set<String> = emptySet(),
    val patients: List<Patient> = emptyList(),
    val allDoctors: List<Profile> = emptyList(),
    val todoSlotsState: SlotsUiState = SlotsUiState.Idle,
    val slotSegments: List<SlotSegment> = emptyList(),
    val slotRanges: Map<String, TimeRange> = emptyMap(),
    val selectedSlotKey: String? = null,
    val currentMonthRevenue: Double = 0.0,
    val revenueGrowthPercent: Double? = null
)

data class DashboardStats(
    val patientCount: Int,
    val stockCounts: Pair<Int, Int>,
    val borrowedCount: Int,
    val dueTodayCount: Int,
    val wasteCount: Int,
    val currentMonthRevenue: Double = 0.0,
    val revenueGrowthPercent: Double? = null
)

data class DashboardExtras(
    val datesWithData: Set<String>,
    val patients: List<Patient>,
    val allDoctors: List<Profile>,
    val todoSlotsState: SlotsUiState
)

data class TodoBundle(
    val todayConsultations: List<ConsultationTodo>,
    val todayVaccinations: List<VaccinationTodo>,
    val visitedConsultations: List<ConsultationTodo>,
    val visitedVaccinations: List<VaccinationTodo>,
    val slots: SlotFilterState
)

data class SlotFilterState(
    val segments: List<SlotSegment> = emptyList(),
    val ranges: Map<String, TimeRange> = emptyMap(),
    val effectiveKey: String? = null
)

/** Orchestrates Dashboard data using unified data streams. */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val syncRepository: SyncRepository,
    private val refreshDataUseCase: com.neochildclinic.feature.sync.domain.RefreshDataUseCase,
    private val networkMonitor: NetworkMonitor,
    private val patientRepository: PatientRepository,
    private val patientTodoRepository: PatientTodoRepository,
    private val inventoryRepository: InventoryRepository,
    private val reminderRepository: ReminderRepository,
    private val wasteRepository: WasteRepository,
    private val borrowRepository: BorrowRepository,
    private val realtimeChangeSubscriptions: RealtimeChangeSubscriptions,
    private val profileRepository: ProfileRepository,
    private val getAvailableSlotsUseCase: GetAvailableSlotsUseCase,
    private val doctorAvailabilityRepository: DoctorAvailabilityRepository,
    private val financeRepository: FinanceRepository
) : ViewModel() {

    private val _allDoctors = MutableStateFlow<List<Profile>>(emptyList())
    private val _todoSlotsState = MutableStateFlow<SlotsUiState>(SlotsUiState.Idle)
    private val _selectedSlotKey = MutableStateFlow<String?>(null)

    // DashboardUiState.errorMessage was a field on a state derived from combine(), so it
    // had no writer: refresh() below caught and only logged, and DashboardScreen's
    // errorMessage snackbar could never fire. A failed dashboard refresh was invisible
    // (NCC-013).
    private val _refreshError = MutableStateFlow<String?>(null)
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private var todoSlotLoadToken = 0

    private val todayStr = LocalDate.now(StatisticsDateUtils.IST).toString()
    private val _selectedDate = MutableStateFlow(todayStr)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    init {
        viewModelScope.launch { runCatching { patientTodoRepository.refresh() } }
        observeTodayPatientRealtimeChanges()
        observeDoctors()
    }

    private fun observeDoctors() {
        profileRepository.allProfiles
            .map { profiles -> profiles.filter { it.role == UserRole.doctor && it.isActive }.sortedBy { it.displayName } }
            .onEach { doctors -> _allDoctors.value = doctors }
            .launchIn(viewModelScope)
    }

    /** Loads available slots for the Today's Patient quick-add dialog (req. 15/16/22). */
    fun loadTodoSlots(doctorId: String?, date: String) {
        if (doctorId.isNullOrBlank() || date.isBlank()) {
            _todoSlotsState.value = SlotsUiState.Idle
            return
        }
        val token = ++todoSlotLoadToken
        _todoSlotsState.value = SlotsUiState.Loading
        viewModelScope.launch {
            val result = getAvailableSlotsUseCase.loadUiState(doctorId, date)
            if (token != todoSlotLoadToken) return@launch
            _todoSlotsState.value = result
        }
    }

    fun clearTodoSlots() {
        _todoSlotsState.value = SlotsUiState.Idle
    }

    fun setSelectedSlot(key: String) {
        _selectedSlotKey.value = key
    }

    /**
     * Resolves the dynamic slot filter inputs for one date: segments come from every
     * active doctor's availability (GetAvailableSlotsUseCase - the same source the
     * add/edit dialogs use) plus any range already booked that day (so a patient whose
     * slot is exception-blocked still has a reachable segment), and ranges resolve each
     * of the day's availabilitySlotIds to its time range for list filtering.
     */
    private suspend fun computeSlotFilter(
        todos: TodoBundle,
        doctors: List<Profile>,
        selectedKey: String?,
        date: String
    ): SlotFilterState = try {
        val availability = doctors.flatMap { doctor ->
            (getAvailableSlotsUseCase(doctor.id, date) as? DoctorAvailabilityResult.Available)
                ?.slots.orEmpty()
        }.map { TimeRange(it.startMinute, it.endMinute) }

        val slotIds = buildSet {
            todos.todayConsultations.forEach { add(it.availabilitySlotId) }
            todos.todayVaccinations.forEach { add(it.availabilitySlotId) }
            todos.visitedConsultations.forEach { add(it.availabilitySlotId) }
            todos.visitedVaccinations.forEach { add(it.availabilitySlotId) }
        }.filterNotNull().filter { it.isNotBlank() }

// One query for the whole day's booked slots, rather than one per id.
// associate() keys by the row's own id, so ids with no matching row are simply
// absent - the same shape the previous per-id mapNotNull produced.
        val ranges = doctorAvailabilityRepository.getWeeklySlotsByIds(slotIds.toList())
            .associate { it.id to it.timeRange }

        val segments = TodaySlotFilter.segments(availability, ranges.values.toList())
        SlotFilterState(segments, ranges, TodaySlotFilter.effectiveKey(segments, selectedKey))
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        // A slot-lookup failure must never take the patient list down with it.
        SlotFilterState()
    }

    // Mirrors PatientListViewModel.observeRealtimeChanges(): Realtime here is only ever a
    // trigger to re-run the existing pull-side refresh(), never a second write path into
    // Room. This is what makes "doctor app open -> new patient appears without a manual
    // refresh" (req. 3/4) work without a second Today's Patient sync framework - the existing
    // sync_queue/SyncWorker path remains the only thing that ever pushes local -> cloud.
    // Channel teardown is handled by RealtimeChangeSubscriptions when viewModelScope cancels.
    @OptIn(kotlinx.coroutines.FlowPreview::class)
    private fun observeTodayPatientRealtimeChanges() {
        viewModelScope.launch {
            // debounce(500) matches PatientListViewModel: a single save produces a burst
            // of postgres events, and without it each event fired a separate two-table
            // pull. onEach is suspending, so refreshes between bursts stay serialized.
            realtimeChangeSubscriptions.tableChanges(
                "todays-patients-db-changes", "consultation_todos", "vaccination_todos"
            ).debounce(500).onEach {
                runCatching { patientTodoRepository.refresh() }
            }.collect()
        }
    }

    private fun monthlyRevenueStats(): Flow<Pair<Double, Double?>> =
        financeRepository.getAllTransactions().map { transactions ->
            val income = transactions.filter { it.type.equals("INCOME", ignoreCase = true) }
            val effective = FinanceCalculator.effectiveIncome(income)

            val curYearMonth = StatisticsDateUtils.currentISTYearMonthObj()
            val prevYearMonth = curYearMonth.minusMonths(1)

            var curRevenue = 0.0
            var prevRevenue = 0.0

            effective.forEach { tx ->
                val reportingDate = FinanceCalculator.resolveReportingDate(tx)
                val localDate = StatisticsDateUtils.parseToISTLocalDate(reportingDate) ?: return@forEach
                val txYearMonth = YearMonth.from(localDate)
                if (txYearMonth == curYearMonth) {
                    curRevenue += tx.amount.coerceAtLeast(0.0)
                } else if (txYearMonth == prevYearMonth) {
                    prevRevenue += tx.amount.coerceAtLeast(0.0)
                }
            }

            val growth = FinanceCalculator.calculateImprovement(curRevenue, prevRevenue)
            curRevenue to growth
        }

    val uiState: StateFlow<DashboardUiState> = combine(
        combine(
            combine(
                patientCount(),
                inventoryStockCounts(),
                borrowedCount(),
                dueCount(),
                wasteCount()
            ) { pCount, stock, borrowed, due, waste ->
                pCount to listOf(stock.first, stock.second, borrowed, due, waste)
            },
            monthlyRevenueStats()
        ) { counts, revenueStats ->
            val (pCount, rest) = counts
            DashboardStats(
                patientCount = pCount,
                stockCounts = rest[0] to rest[1],
                borrowedCount = rest[2],
                dueTodayCount = rest[3],
                wasteCount = rest[4],
                currentMonthRevenue = revenueStats.first,
                revenueGrowthPercent = revenueStats.second
            )
        },
        combine(
            syncRepository.syncState,
            syncRepository.getPendingCount(),
            networkMonitor.isOnline
        ) { syncState, pendingCount, isOnline ->
            Triple(syncState, pendingCount, isOnline)
        },
        _selectedDate.flatMapLatest { date ->
            combine(
                patientTodoRepository.getConsultationsByDateAndStatus(date, "PENDING"),
                patientTodoRepository.getVaccinationsByDateAndStatus(date, "PENDING"),
                patientTodoRepository.getConsultationsByDateAndStatus(date, "COMPLETED"),
                patientTodoRepository.getVaccinationsByDateAndStatus(date, "COMPLETED")
            ) { pCons, pVacc, cCons, cVacc ->
                TodoBundle(pCons, pVacc, cCons, cVacc, SlotFilterState())
            }.flatMapLatest { bundle ->
                combine(_allDoctors, _selectedSlotKey) { doctors, key -> doctors to key }
                    .flatMapLatest { (doctors, selectedKey) ->
                        flow {
                            emit(bundle.copy(slots = computeSlotFilter(bundle, doctors, selectedKey, date)))
                        }
                    }
            }
        },
        combine(
            _selectedDate.flatMapLatest { date ->
                val selected = try {
                    java.time.LocalDate.parse(date)
                } catch (_: java.time.format.DateTimeParseException) {
                    java.time.LocalDate.now(StatisticsDateUtils.IST)
                }
                val start = selected.withDayOfMonth(1)
                val end = start.plusMonths(1).minusDays(1)
                patientTodoRepository.getDatesWithData(start.toString(), end.toString()).map { it.toSet() }
            },
            patientRepository.allPatients,
            _allDoctors,
            _todoSlotsState
        ) { dates, patients, doctors, slots ->
            DashboardExtras(dates, patients, doctors, slots)
        },
        _refreshError
    ) { stats, sync, bundle, extra, refreshError ->
        val slots = bundle.slots
        fun pass(slotId: String?): Boolean =
            TodaySlotFilter.passes(slots.effectiveKey, slots.ranges, slotId)
        DashboardUiState(
            errorMessage = refreshError,
            patientCount = stats.patientCount,
            lowStockCount = stats.stockCounts.first,
            borrowedCount = stats.borrowedCount,
            dueTodayCount = stats.dueTodayCount,
            wasteCount = stats.wasteCount,
            outOfStockCount = stats.stockCounts.second,
            currentMonthRevenue = stats.currentMonthRevenue,
            revenueGrowthPercent = stats.revenueGrowthPercent,
            syncState = sync.first,
            isOnline = sync.third,
            pendingSyncCount = sync.second,
            todayConsultations = bundle.todayConsultations.filter { pass(it.availabilitySlotId) },
            todayVaccinations = bundle.todayVaccinations.filter { pass(it.availabilitySlotId) },
            visitedConsultations = bundle.visitedConsultations.filter { pass(it.availabilitySlotId) },
            visitedVaccinations = bundle.visitedVaccinations.filter { pass(it.availabilitySlotId) },
            datesWithData = extra.datesWithData,
            patients = extra.patients,
            allDoctors = extra.allDoctors,
            todoSlotsState = extra.todoSlotsState,
            slotSegments = slots.segments,
            slotRanges = slots.ranges,
            selectedSlotKey = slots.effectiveKey
        )
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    fun setSelectedDate(date: String) {
        _selectedDate.value = date
    }

    fun toggleTodoStatus(item: Any) {
        viewModelScope.launch {
            when (item) {
                is ConsultationTodo -> {
                    val newStatus = if (item.status == "PENDING") "COMPLETED" else "PENDING"
                    patientTodoRepository.updateStatus("CONSULTATION_TODO", item.id, newStatus)
                }
                is VaccinationTodo -> {
                    val newStatus = if (item.status == "PENDING") "COMPLETED" else "PENDING"
                    patientTodoRepository.updateStatus("VACCINATION_TODO", item.id, newStatus)
                }
            }
        }
    }

    fun addConsultation(patient: Patient) {
        addConsultationDirect(
            patientId = patient.id,
            name = patient.name,
            mobile = patient.phone,
            address = patient.address.orEmpty()
        )
    }

    fun addConsultationDirect(
        id: String? = null,
        patientId: String? = null,
        name: String,
        mobile: String,
        address: String,
        doctorId: String? = null,
        doctorName: String? = null,
        availabilitySlotId: String? = null
    ) {
        viewModelScope.launch {
            val todo = ConsultationTodo(
                id = id?.ifBlank { java.util.UUID.randomUUID().toString() } ?: java.util.UUID.randomUUID().toString(),
                patientId = patientId,
                name = name,
                mobile = mobile,
                address = address,
                todoDate = _selectedDate.value,
                doctorId = doctorId,
                doctorName = doctorName,
                availabilitySlotId = availabilitySlotId
            )
            patientTodoRepository.addConsultation(todo)
        }
    }

    fun addVaccination(patient: Patient, vaccineNames: String) {
        addVaccinationDirect(
            patientId = patient.id,
            name = patient.name,
            mobile = patient.phone,
            address = patient.address.orEmpty(),
            vaccineNames = vaccineNames
        )
    }

    fun addVaccinationDirect(
        id: String? = null,
        patientId: String? = null,
        name: String,
        mobile: String,
        address: String,
        vaccineNames: String,
        doctorId: String? = null,
        doctorName: String? = null,
        availabilitySlotId: String? = null
    ) {
        viewModelScope.launch {
            val todo = VaccinationTodo(
                id = id?.ifBlank { java.util.UUID.randomUUID().toString() } ?: java.util.UUID.randomUUID().toString(),
                patientId = patientId,
                name = name,
                mobile = mobile,
                vaccineNames = vaccineNames,
                address = address,
                todoDate = _selectedDate.value,
                doctorId = doctorId,
                doctorName = doctorName,
                availabilitySlotId = availabilitySlotId
            )
            patientTodoRepository.addVaccination(todo)
        }
    }

    fun deleteConsultation(id: String) {
        viewModelScope.launch {
            try {
                patientTodoRepository.deleteConsultation(id)
            } catch (e: Exception) {
                android.util.Log.e("DashboardVM", "Delete consultation failed", e)
            }
        }
    }
    fun deleteVaccination(id: String) {
        viewModelScope.launch {
            try {
                patientTodoRepository.deleteVaccination(id)
            } catch (e: Exception) {
                android.util.Log.e("DashboardVM", "Delete vaccination failed", e)
            }
        }
    }

    private fun patientCount(): Flow<Int> = patientRepository.getPatientCount()

    private fun inventoryStockCounts(): Flow<Pair<Int, Int>> = inventoryRepository.getStockCounts()

    private fun borrowedCount(): Flow<Int> = borrowRepository.getActiveBorrowCount()

    private fun dueCount(): Flow<Int> = reminderRepository.getDueTodayCount()

    private fun wasteCount(): Flow<Int> = wasteRepository.getWasteCount()

    /** Clears [DashboardUiState.errorMessage] once the snackbar has been shown. */
    fun clearError() {
        _refreshError.value = null
    }

    fun refresh() {
        if (_isRefreshing.value) return
        viewModelScope.launch {
            _isRefreshing.value = true
            try {
                syncRepository.processNextItems()
                // Push AND pull. This screen only uploaded before, so the spinner meant
                // "uploaded": a patient registered on another device never appeared and the
                // user concluded the entry was lost. Matches PatientListViewModel and
                // StatisticsViewModel, which both call refreshDataUseCase().
                refreshDataUseCase()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                android.util.Log.e("DashboardVM", "Sync refresh failed", e)
                _refreshError.value = e.message
                    ?: "Could not sync. Your data is saved on this device and will upload when the connection returns."
            } finally {
                _isRefreshing.value = false
            }
        }
    }
}
