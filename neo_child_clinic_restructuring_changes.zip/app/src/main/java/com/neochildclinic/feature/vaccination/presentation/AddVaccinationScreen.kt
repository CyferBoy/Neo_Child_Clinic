package com.neochildclinic.feature.vaccination.presentation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.neochildclinic.core.ui.*
import com.neochildclinic.feature.doctor.presentation.DoctorDropdown
import com.neochildclinic.core.designsystem.*
import com.neochildclinic.domain.model.Patient

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddVaccinationScreen(
    patientId: String? = null,
    vaccinationId: String? = null,
    initialVaccineName: String? = null,
    onBack: () -> Unit,
    viewModel: AddVaccinationViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val isEdit = vaccinationId != null
    var editGivenDate by rememberSaveable { mutableStateOf(false) }
    var editDoctor by rememberSaveable { mutableStateOf(false) }
    var editVaccineBatch by rememberSaveable { mutableStateOf(false) }
    var editQuantity by rememberSaveable { mutableStateOf(false) }
    var editPayment by rememberSaveable { mutableStateOf(false) }
    var editNextVaccination by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(patientId) {
        patientId?.let { viewModel.loadPatient(it) }
    }

    LaunchedEffect(vaccinationId) {
        viewModel.loadVaccination(vaccinationId)
    }

    LaunchedEffect(initialVaccineName) {
        viewModel.setInitialVaccine(initialVaccineName)
    }

    LaunchedEffect(uiState.saveSuccess) {
        if (uiState.saveSuccess) {
            onBack()
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                BackTopAppBar(
                    title = { Text(if (isEdit) "Edit Vaccination" else "Add Vaccination") },
                    onBack = onBack,
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        // Was onPrimary (white) on a background-coloured bar: the
                        // back arrow was invisible.
                        navigationIconContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = Elevation.sheet,
                    shadowElevation = Elevation.sheet
                ) {
                    // Was PaddingValues(Spacing.lg).let { ... } - a bare value class
                    // that padded nothing and read as if it did. The button below
                    // already carries its own padding.
                    StandardButton(
                        onClick = {
                                viewModel.saveVaccination(
                                    editGivenDate = editGivenDate,
                                    editDoctor = editDoctor,
                                    editVaccineBatch = editVaccineBatch,
                                    editQuantity = editQuantity,
                                    editNextVaccination = editNextVaccination
                                )
                            },
                            modifier = Modifier.padding(Spacing.lg).fillMaxWidth(),
                            enabled = !isEdit || !uiState.isVaccinationLoading,
                            isLoading = uiState.isLoading
                        ) {
                            Text(
                                if (isEdit && uiState.isVaccinationLoading) "Loading..."
                                else if (isEdit) "Save Changes" else "Save Vaccination",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.lg),
                contentPadding = PaddingValues(top = Spacing.lg, bottom = 100.dp)
            ) {
                // 1. Patient Summary
                uiState.patient?.let { patient ->
                    item { PatientSummaryCard(patient) }
                }

                // 2. Given Date
                item {
                    EditSectionHeader(
                        title = "Given Date",
                        checked = if (isEdit) editGivenDate else true,
                        enabled = isEdit,
                        onCheckedChange = { editGivenDate = it }
                    )
                    if (!isEdit || editGivenDate) {
                        DateDropdownPicker(
                            label = "Given Date*",
                            currentDate = uiState.givenDate,
                            onDateSelected = { viewModel.updateGivenDate(it) }
                        )
                    } else {
                        ReadOnlyValue(uiState.givenDate)
                    }
                }

                // 2.5 Doctor Selection
                item {
                    EditSectionHeader(
                        title = "Doctor",
                        checked = if (isEdit) editDoctor else true,
                        enabled = isEdit,
                        onCheckedChange = { editDoctor = it }
                    )
                    if (!isEdit || editDoctor) {
                        DoctorDropdown(
                            doctors = uiState.allDoctors,
                            selectedDoctor = uiState.selectedDoctor,
                            onDoctorSelected = { viewModel.selectDoctor(it) },
                            isError = uiState.doctorError
                        )
                    } else {
                        ReadOnlyValue(uiState.selectedDoctor?.displayName ?: "Not selected")
                    }
                }

                // 3. Vaccine & Batch + Quantity
                item {
                    EditSectionHeader(
                        title = "Vaccine & Batch",
                        checked = if (isEdit) editVaccineBatch else true,
                        enabled = isEdit,
                        onCheckedChange = { editVaccineBatch = it }
                    )
                    if (isEdit && !editVaccineBatch && !editQuantity) {
                        ReadOnlyValue(uiState.vaccinesGiven.joinToString("\n") { row ->
                            val vaccine = row.selectedVaccine?.brandName ?: "Not selected"
                            val batch = row.selectedBatch?.batchNumber ?: "No batch"
                            "$vaccine • Batch: $batch • Quantity: ${row.quantity}"
                        })
                    }
                }
                if (isEdit) {
                    item {
                        EditSectionHeader(
                            title = "Quantity",
                            checked = editQuantity,
                            enabled = true,
                            onCheckedChange = { editQuantity = it }
                        )
                    }
                }
                if (!isEdit || editVaccineBatch || editQuantity) {
                    items(uiState.vaccinesGiven, key = { it.id }) { row ->
                        VaccineRow(
                            state = row,
                            inventory = uiState.inventory,
                            givenDate = uiState.givenDate,
                            onVaccineSelected = { viewModel.selectVaccine(row.id, it) },
                            onBatchSelected = { viewModel.selectBatch(row.id, it) },
                            onQuantityChange = { viewModel.updateQuantity(row.id, it) },
                            allowVaccineBatchEdit = !isEdit || editVaccineBatch,
                            allowQuantityEdit = !isEdit || editQuantity,
                            onRemove = { viewModel.removeVaccineRow(row.id) },
                            isOnlyRow = uiState.vaccinesGiven.size == 1
                        )
                    }
                    item {
                        if (!isEdit || editVaccineBatch) {
                            TextButton(onClick = { viewModel.addVaccineRow() }) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(Spacing.xs))
                                Text("Add Vaccine")
                            }
                        }
                    }
                }

                // 4. Payment Section
                item {
                    EditSectionHeader(
                        title = "Payment",
                        checked = if (isEdit) editPayment else true,
                        enabled = isEdit,
                        onCheckedChange = { editPayment = it }
                    )
                    if (!isEdit || editPayment) {
                        PaymentSection(
                            cash = uiState.cashAmount,
                            online = uiState.onlineAmount,
                            total = uiState.totalAmount,
                            withFees = uiState.withFees,
                            doctorsAcc = uiState.doctorsAcc,
                            onCashChange = { viewModel.updateCash(it) },
                            onOnlineChange = { viewModel.updateOnline(it) },
                            onFeesToggle = { viewModel.updateWithFees(it) },
                            onAccToggle = { viewModel.updateDoctorsAccount(it) }
                        )
                    } else {
                        ReadOnlyValue("Cash: ₹${uiState.cashAmount} | Online: ₹${uiState.onlineAmount}\nTotal: ₹${uiState.totalAmount}")
                    }
                }

                // 5. Next Vaccination Section
                item {
                    EditSectionHeader(
                        title = "Next Vaccination",
                        checked = if (isEdit) editNextVaccination else true,
                        enabled = isEdit,
                        onCheckedChange = { editNextVaccination = it }
                    )
                    if (isEdit && !editNextVaccination) {
                        ReadOnlyValue(if (uiState.nextVaccinationGroups.isEmpty()) "No next vaccination" else uiState.nextVaccinationGroups.joinToString("\n") { group ->
                            val itemsStr = group.items.joinToString(", ") { it.vaccine?.brandName ?: it.type }
                            "$itemsStr • Due: ${group.dueDate}"
                        })
                    }
                }
                if (nextVaccinationSectionActive(isEdit = isEdit, editNextVaccination = editNextVaccination)) {
                    items(uiState.nextVaccinationGroups, key = { it.id }) { group ->
                        NextVaccinationGroupCard(
                            group = group,
                            inventory = uiState.inventory,
                            availableTypes = uiState.availableDueTypes,
                            onDueDateSelected = { viewModel.updateNextVaccinationGroupDate(group.id, it) },
                            onAddItem = { viewModel.addNextVaccinationItem(group.id) },
                            onRemoveGroup = { viewModel.removeNextVaccinationGroup(group.id) },
                            onCancelGroup = { viewModel.cancelNextVaccinationGroup(group.id) },
                            onTypeSelected = { itemId, type -> viewModel.updateNextVaccinationItem(group.id, itemId, type = type) },
                            onVaccineSelected = { itemId, vaccine -> viewModel.updateNextVaccinationItem(group.id, itemId, vaccine = vaccine) },
                            onRemoveItem = { itemId -> viewModel.removeNextVaccinationItem(group.id, itemId) },
                            onCancelItem = { itemId -> viewModel.cancelNextVaccinationItem(group.id, itemId) }
                        )
                    }
                    item {
                        OutlinedButton(onClick = { viewModel.addNextVaccinationGroup() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(Spacing.sm))
                            Text(if (uiState.nextVaccinationGroups.isEmpty()) "Add Next Vaccination" else "Add Another Date")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditSectionHeader(
    title: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (enabled) {
            Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        } else {
            Spacer(Modifier.width(Spacing.md))
        }
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = if (!enabled || !checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun PatientSummaryCard(patient: Patient) {
    val initials = remember(patient.name) {
        patient.name.trim().split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .map { it.first().uppercase() }
            .joinToString("")
            .ifBlank { "P" }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier.padding(Spacing.card),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = androidx.compose.foundation.shape.CircleShape,
                color = MaterialTheme.colorScheme.primary
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = initials,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
            Spacer(Modifier.width(Spacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = patient.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                val clinicId = if (patient.patientClinicId.isNullOrBlank() || patient.patientClinicId.startsWith("TEMP-")) "Not Assigned" else patient.patientClinicId
                Text(
                    text = "${patient.gender} · DOB: ${patient.dob} · ID: $clinicId",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }
    }
}
