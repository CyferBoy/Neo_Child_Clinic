package com.neochildclinic.app

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.neochildclinic.core.security.BiometricLockManager
import com.neochildclinic.core.security.BiometricAuthenticator
import com.neochildclinic.core.designsystem.NeoChildTheme
import com.neochildclinic.core.preferences.PreferenceManager
import com.neochildclinic.core.ui.LockScreen
import com.neochildclinic.feature.update.presentation.AppUpdateDialog
import com.neochildclinic.feature.update.presentation.AppUpdateViewModel
import com.neochildclinic.core.sync.SyncManagerImpl
import com.neochildclinic.feature.auth.domain.repository.DeviceRepository
import com.neochildclinic.core.security.AuthViewModel
import com.neochildclinic.core.preferences.NotificationSettingsManager
import com.neochildclinic.core.notification.NotificationHelper
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.handleDeeplinks
import io.github.jan.supabase.postgrest.Postgrest
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.security.MessageDigest
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    
    @Inject
    lateinit var supabaseClient: io.github.jan.supabase.SupabaseClient

    @Inject
    lateinit var auth: Auth
    
    @Inject
    lateinit var postgrest: Postgrest
    
    @Inject
    lateinit var notificationHelper: NotificationHelper

    @Inject
    lateinit var settingsManager: NotificationSettingsManager

    @Inject
    lateinit var syncManager: SyncManagerImpl

    @Inject
    lateinit var deviceRepository: DeviceRepository

    @Inject
    lateinit var preferenceManager: PreferenceManager

    @Inject
    lateinit var sessionManager: com.neochildclinic.core.security.SessionManager

    @Inject
    lateinit var profileRepository: com.neochildclinic.feature.profile.domain.repository.ProfileRepository

    private val authViewModel: AuthViewModel by viewModels()
    private val appUpdateViewModel: AppUpdateViewModel by viewModels()

    private var openDueTab by mutableStateOf(value = false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAuthDeeplink(intent)
        handleIntent(intent)
        
        notificationHelper.cancelSummaryNotification()

        // SECURITY: Prevent screenshots and recording of patient data
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        
        syncManager.scheduleSync()

        enableEdgeToEdge()
        setContent {
            val themeMode by preferenceManager.themeMode.collectAsState(initial = "system")
            val darkTheme = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }

            NeoChildTheme(darkTheme = darkTheme) {
                val isLocked by BiometricLockManager.isAppLocked.collectAsState()
                val lockStateResolved by BiometricLockManager.lockStateResolved.collectAsState()
                val currentProfile by authViewModel.profile.collectAsState()
                val allProfiles by profileRepository.allProfiles.collectAsState(initial = emptyList())
                val currentUserId = remember { auth.currentSessionOrNull()?.user?.id }

                val currentUserName = remember(currentProfile, allProfiles, currentUserId) {
                    currentProfile?.displayName?.takeIf { it.isNotBlank() }
                        ?: allProfiles.find { it.id == currentUserId }?.displayName?.takeIf { it.isNotBlank() }
                        ?: sessionManager.getCurrentUserDisplayName("").takeIf { it.isNotBlank() && it != "Unknown" }
                        ?: auth.currentSessionOrNull()?.user?.email?.substringBefore("@")?.replaceFirstChar { it.uppercase() }
                        ?: ""
                }

                val navController = rememberNavController()
                val updateInfo by appUpdateViewModel.updateInfo.collectAsState()
                val startupPopup by appUpdateViewModel.startupPopup.collectAsState()
                val installingUpdate by appUpdateViewModel.installing.collectAsState()
                val downloadProgress by appUpdateViewModel.downloadProgress.collectAsState()
                
                Box(modifier = Modifier.fillMaxSize()) {
                    // The navigation tree - and every ViewModel scoped to it - is only composed
                    // once the app is known to be unlocked. Previously it was always composed and
                    // LockScreen was drawn on top, so a locked app still had every screen's
                    // ViewModel alive and its patient rows in memory behind an overlay (NCC-012).
                    // navController stays outside the gate: NavController saves its own back
                    // stack, so unlocking returns the user where they were.
                    if (lockStateResolved && !isLocked) {
                        AppNavigation(navController = navController, appUpdateViewModel = appUpdateViewModel)
                    }

                    // Unknown state renders neither the app nor the lock screen - deciding takes
                    // as long as the session status takes to resolve. A progress indicator is
                    // honest here; patient data is not an option.
                    if (!lockStateResolved) {
                        androidx.compose.foundation.layout.Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            androidx.compose.material3.CircularProgressIndicator()
                        }
                    }

                    if (isLocked) {
                        LockScreen(
                            onAuthenticate = { authenticateWithBiometrics() },
                            onPasswordAuthenticate = { authenticateWithAccountPassword(it) },
                            userName = currentUserName
                        )
                    }

                    // Small temporary heads-up popup for a silently-detected new version -
                    // never the full dialog itself. See AppUpdateViewModel.checkForUpdates
                    // for why this is only ever populated for a genuine available-update
                    // result from a silent (non-manual) check, at most once per session.
                    // lastStartupPopupInfo keeps the banner's content available while it
                    // plays its slide/fade-out exit animation, since startupPopup itself
                    // is already null by the time that animation starts.
                    var lastStartupPopupInfo by remember { mutableStateOf<com.neochildclinic.feature.update.data.AppUpdateInfo?>(null) }
                    startupPopup?.let { lastStartupPopupInfo = it }
                    androidx.compose.animation.AnimatedVisibility(
                        visible = startupPopup != null,
                        enter = androidx.compose.animation.slideInVertically() + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.slideOutVertically() + androidx.compose.animation.fadeOut(),
                        modifier = Modifier.align(Alignment.TopCenter),
                    ) {
                        lastStartupPopupInfo?.let { info ->
                            com.neochildclinic.feature.update.presentation.StartupUpdateBanner(
                                info = info,
                                onTap = { appUpdateViewModel.openUpdateFromStartupPopup() },
                                onDismiss = { appUpdateViewModel.dismissStartupPopup() }
                            )
                        }
                    }

                    updateInfo?.let { info ->
                        AppUpdateDialog(
                            info = info,
                            installing = installingUpdate,
                            progress = downloadProgress,
                            onUpdate = { appUpdateViewModel.installUpdate() },
                            onLater = { appUpdateViewModel.dismissUpdate() },
                            onDontRemindMe = { appUpdateViewModel.dontRemindMe() }
                        )
                    }
                }

                // Permission request for Android 13+
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    // Notifications permission granted/denied
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                LaunchedEffect(openDueTab) {
                    if (openDueTab) {
                        navController.navigate(Routes.DUE)
                        openDueTab = false
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Notify Lock Manager that app is resumed
        BiometricLockManager.onAppResume()
        
        lifecycleScope.launch {
            authViewModel.refreshSessionStatus()
            checkAppLock()
            // Device heartbeat is non-critical; DeviceRepositoryImpl handles failures so
            // a user_devices timeout can never prevent the main data sync from being queued.
            deviceRepository.updateActivity()
            settingsManager.updateLastOpenTimestamp()
            syncManager.scheduleSync()
            if (auth.currentSessionOrNull() != null) {
                appUpdateViewModel.checkForUpdates()
                com.neochildclinic.feature.widget.data.WidgetUtils.updateWidget(this@MainActivity)
            }
        }
    }

    private fun checkAppLock() {
        lifecycleScope.launch {
            try {
                val status = authViewModel.awaitResolvedSessionStatus()
                // Same offline fallback as Navigation.kt's start-destination resolution: a
                // timed-out (null) status almost always means no network at launch, not "not
                // logged in" - and app-lock exists specifically to protect an already logged-in
                // user's local data, so it should still apply in that case rather than being
                // silently skipped.
                val isAuthenticated = status is io.github.jan.supabase.auth.status.SessionStatus.Authenticated ||
                    (status == null && authViewModel.currentUser != null)
                if (!isAuthenticated) return@launch

                val settings = settingsManager.settingsFlow.first()
                BiometricLockManager.setProtectionEnabled(settings.biometricLockEnabled)
                if (!settings.biometricLockEnabled || BiometricLockManager.isLockSuppressed()) {
                    BiometricLockManager.unlockBecauseProtectionIsDisabled()
                    com.neochildclinic.feature.widget.data.WidgetUtils.updateWidget(this@MainActivity)
                    return@launch
                }

                val currentTime = System.currentTimeMillis()
                val lastOpen = settings.lastAppOpenTimestamp
                val thresholdMillis = settings.inactivityDaysThreshold * 24L * 60L * 60L * 1000L
            
                val isLocked = BiometricLockManager.isAppLocked.value
                // needsAuth survives process death (set on screen-off/lock, cleared only by a
                // successful unlock), unlike the in-memory state above.
                if (isLocked || settings.needsAuth || settings.authOnEveryOpen || (currentTime - lastOpen > thresholdMillis)) {
                    BiometricLockManager.lock()
                    authenticateWithBiometrics()
                }
            } finally {
                // Reached on every path, including the not-authenticated early return.
                // Without this the UI would sit on the progress indicator forever for
                // logged-out users.
                BiometricLockManager.markLockStateResolved()
            }
        }
    }

    private fun authenticateWithBiometrics() {
        BiometricAuthenticator.authenticate(
            activity = this,
            title = "Clinic Access",
            subtitle = "Authenticate to access patient data"
        ) {
            BiometricLockManager.unlockAfterKeystoreVerification()
            com.neochildclinic.feature.widget.data.WidgetUtils.updateWidget(this@MainActivity)
        }
    }

    private fun authenticateWithAccountPassword(password: String) {
        lifecycleScope.launch {
            val result = authViewModel.reauthenticateWithPassword(password)
            if (result.isSuccess) {
                BiometricLockManager.unlockAfterKeystoreVerification()
                com.neochildclinic.feature.widget.data.WidgetUtils.updateWidget(this@MainActivity)
            } else if (result.exceptionOrNull()?.message == "No account email is available.") {
                // No session email to authenticate against - nothing to unlock or relock,
                // just tell the user why the lock-screen password path is unavailable.
                Toast.makeText(this@MainActivity, "No account email is available.", Toast.LENGTH_SHORT).show()
            } else {
                Log.e("ACCOUNT_AUTH", "Account password authentication failed", result.exceptionOrNull())
                BiometricLockManager.lock()
                Toast.makeText(this@MainActivity, "Incorrect account password.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthDeeplink(intent)
        handleIntent(intent)
    }

    private fun handleAuthDeeplink(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme.equals("neochild", ignoreCase = true) &&
            uri.host.equals("auth-callback", ignoreCase = true)
        ) {
            supabaseClient.handleDeeplinks(intent)
        }
    }

    private fun handleIntent(intent: Intent?) {
        // Glance action parameters are passed as extras with keys prefixed or mapped
        // For actionStartActivity<MainActivity>(actionParametersOf(key to value))
        // The key is usually the string name used in ActionParameters.Key
        if (intent?.extras?.containsKey("OPEN_DUE_TAB") == true) {
            openDueTab = intent.getBooleanExtra("OPEN_DUE_TAB", false)
        }
        if (intent?.getBooleanExtra("CHECK_APP_UPDATE", false) == true) {
            if (auth.currentSessionOrNull() != null) {
                // Reached only by tapping the existing update notification (see
                // NotificationHelper.showUpdateNotification/showUpdateInstallFailed) - that
                // notification's own contract is "tap it -> the full dialog opens", distinct
                // from a plain app launch/resume, so this is a manual check, not silent.
                appUpdateViewModel.checkForUpdates(isManual = true)
            }
        }
    }
}
